import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-formulario-propietario',
  templateUrl: './formulario-propietario.page.html',
  styleUrls: ['./formulario-propietario.page.scss'],
})
export class FormularioPropietarioPage implements OnInit {
  propietarioForm: FormGroup;

  constructor(public fb: FormBuilder,
    private router: Router,) {
  }

  ngOnInit() {
    this.propietarioForm = this.fb.group({
      nombrePropietario: ['', Validators.required],
      apellidoPropietario: ['', Validators.required],
      edadPropietario: ['', Validators.required],
      ocupacionPropietario: ['', Validators.required],
      direccionPropietario: ['', Validators.required],
      correoPropietario: ['', Validators.required],
      celularPropietario: ['', [ Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)]]
    });
  }

  enviarFormularioPropietario(){
    if (this.propietarioForm.invalid) {
      console.log('Por favor ingrese todos los campos requeridos!')
      //return false;
    } else { 
      console.log(this.propietarioForm.value)
      this.router.navigate(['/formulario-mascota']);
    }
    // this.router.navigate(['/formulario-mascota']);
  }
}
