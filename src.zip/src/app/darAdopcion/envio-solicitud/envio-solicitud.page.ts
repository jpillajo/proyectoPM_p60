import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-envio-solicitud',
  templateUrl: './envio-solicitud.page.html',
  styleUrls: ['./envio-solicitud.page.scss'],
})
export class EnvioSolicitudPage implements OnInit {
  constructor() { }

  ngOnInit() {
  }

}
