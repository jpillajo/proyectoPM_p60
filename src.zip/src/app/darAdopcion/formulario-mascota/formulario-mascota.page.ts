import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formulario-mascota',
  templateUrl: './formulario-mascota.page.html',
  styleUrls: ['./formulario-mascota.page.scss'],
})
export class FormularioMascotaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
